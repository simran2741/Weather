package cz.martykan.forecastie;

public class Constants {
    public static final String  DEFAULT_CITY = "Pune";
    public static final String  DEFAULT_LAT = "18.52";
    public static final String  DEFAULT_LON = "73.86";
    public static final String DEFAULT_CITY_ID = "1259229";
    public static final int DEFAULT_ZOOM_LEVEL = 7;
}
