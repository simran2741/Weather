We welcome any and all contributions to Forecastie. Please add suggestions, bugs or requests for new features to the Issues page.

The Issues page is also the best place to ask questions about the code, the structure of the software, release schedule, etc.

We also accept pull requests; anything you submit will be reviewed and discussed, and merged if appropriate. Please take the time to read relevant Issues, or open one yourself on the topic.
